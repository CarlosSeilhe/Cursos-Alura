package com.programar.cursoop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoopApplicationTests {

	@Test
	void contextLoads() {
	}

}
